Your Game Title
===============

Entry in PyWeek #4  <http://www.pyweek.org/4/>
Team: YOUR TEAM NAME (leave the "Team: bit")
Members: YOUR TEAM MEMBERS (leave the "Members: bit")


DEPENDENCIES:

You might need to install some of these before running the game:

  Python:     http://www.python.org/
  PyGame:     http://www.pygame.org/
  PyOpenGL:   http://pyopengl.sf.net/



RUNNING THE GAME:

On Windows or Mac OS X, locate the "run_game.pyw" file and double-click it.

Othewise open a terminal / console and "cd" to the game directory and run:

  python run_game.py



HOW TO PLAY THE GAME:

Move the cursor around the screen with the mouse.

Press the left mouse button to fire the ducks.



LICENSE:

This game skellington is placed in the Public Domain.

